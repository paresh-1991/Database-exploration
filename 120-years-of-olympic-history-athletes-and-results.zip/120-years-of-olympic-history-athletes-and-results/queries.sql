
-- list names of countries which paticpated in olympics but never host the olympics yet?

-- solution: this query result the names of countries from country table which never host the olympics.

select distinct country                                         -- each country name chosen 
from country                                                    -- from country table
where country_id not in(select country_id from olympic_games);  -- by comparing country id from country table to olympic_games table,
                                                                -- country id which is not available in olympic games are the countries which never hosted olympics.


-- query using agg function and select, grouby, having.
-- list the name of countries and the times they represented by thier athletes, 5times or more?


select country, count(athlete_id) as no_of_times_participated 
from participates_in 
join athlete on participates_in.athlete_id = athlete.id  -- providing link of athlete id attribute between two table, particpate_in and athlete. to see which athlete particpated in event as each athlete represnt a country
join country on athlete.country_id = country.country_id  -- providing link of country id attribute between two table, country and athlete. to see which athlete represent which country.
group by country										 -- grouping it by country
having count(athlete_id) >= 5;                           -- counting the number of athletes particpates more than or equal to 5 times.


-- window function
-- for each athlete, determine their country, age and number of athlete with similar age.

select "name", country, age, count(age) over(partition by age order by age) as no_of_athlete_with_similar_age  -- selecting attribute, and partitioning the table by age 
from athlete
join country on country.country_id = athlete.country_id                                                        -- joining the table to get the country name from country id.
