--
-- nullme: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;
COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';

-- to enullble functions like crosstab
CREATE EXTENSION IF NOT EXISTS tablefunc;


create table olympics.athelete(
	id INT not null,
	"name" Varchar(300) not null,
	sex varchar(1),
	"height" INT,
	weight INT
);

ALTER TABLE olympics.athelete OWNER TO postgres;


select * from olympics.athelete;


create table olympics.Team (
	COUNTRY varchar(30) not null,
	NOC Varchar(30) not null
);
ALTER TABLE olympics.team OWNER TO postgres;

select*from olympics.team;

create table olympics.part_of (
	NOC Varchar(30) not null,
	athelete_id INT not null
);
ALTER TABLE olympics.team OWNER TO postgres;


create table olympics.olympic_games(
	city Varchar(40) not null,
	"year" INT not null,
	season varchar(20) not null
);
ALTER TABLE olympics.olympic_games OWNER TO postgres;


create table olympics.performs_in(
	athelete_id INT not null,
	olympic_city Varchar(40),
	olympic_year int not null,
	"Event" varchar(100) not null,
	"result" varchar(20)
);
ALTER TABLE olympics.performs_in OWNER TO postgres;



create table olympics.participates_in(
	team_NOC varchar(15)not null,
	olympic_city Varchar(40),
	olympic_year int
);
ALTER TABLE olympics.participates_in OWNER TO postgres;

-- primary keys

ALTER TABLE ONLY olympics.athelete
    ADD CONSTRAINT prim_key_athelete PRIMARY KEY (id);

ALTER TABLE ONLY olympics.part_of
    ADD CONSTRAINT prim_key_partof PRIMARY KEY (athelete_id);   
   
ALTER TABLE ONLY olympics.team
    ADD CONSTRAINT prim_key_team PRIMARY KEY (NOC);

ALTER TABLE ONLY olympics.olympic_games
    ADD CONSTRAINT prim_key_ogames PRIMARY KEY (city, "year");

ALTER TABLE ONLY olympics.performs_in
    ADD CONSTRAINT prim_key_Perin PRIMARY KEY (athelete_id, "Event", olympic_year);

ALTER TABLE ONLY olympics.participates_in
    ADD CONSTRAINT prim_key_parin PRIMARY KEY (team_NOC, olympic_city, olympic_year);


   
insert into olympics.athelete(id, "name", sex,  height, weight) values(1,'A Dijiang','M',180,80);

insert into olympics.athelete(id, "name", sex,  height, weight) values(2,'A Lamusi','M',170,60);

insert into olympics.athelete(id, "name", sex,  height, weight) values(3,'Gunnullr Nielsen Aaby','M', null,null);

insert into olympics.athelete(id, "name", sex,  height, weight) values(4,'Edgar Lindenullu Aabye','M',null,null);

insert into olympics.athelete(id, "name", sex,  height, weight) values(5,'Christine Jacoba Aaftink','F',185,82);

insert into olympics.athelete(id, "name", sex,  height, weight) values(6,'Per Knut Aaland','M',188,75);

insert into olympics.athelete(id, "name", sex,  height, weight) values(7,'John Aalberg','M',183,72);
insert into olympics.athelete(id, "name", sex,  height, weight) values(8,'"Cornelia ""Cor"" Aalten (-Strannood)"','F',168,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(9,'Antti Sami Aalto','M',186,96);
insert into olympics.athelete(id, "name", sex,  height, weight) values(10,'"Einullr Ferdinullnd ""Einullri"" Aalto"','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(11,'Jorma Ilmari Aalto','M',182,76);
insert into olympics.athelete(id, "name", sex,  height, weight) values(12,'Jyri Tapani Aalto','M',172,70);
insert into olympics.athelete(id, "name", sex,  height, weight) values(13,'Minnull Maarit Aalto','F',159,55);
insert into olympics.athelete(id, "name", sex,  height, weight) values(14,'Pirjo Hannele Aalto (Mattila-)','F',171,65);
insert into olympics.athelete(id, "name", sex,  height, weight) values(15,'Arvo Ossian Aaltonen','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(16,'Juhamatti Tapio Aaltonen','M',184,85);
insert into olympics.athelete(id, "name", sex,  height, weight) values(17,'Paavo Johannes Aaltonen','M',175,64);
insert into olympics.athelete(id, "name", sex,  height, weight) values(18,'Timo Antero Aaltonen','M',189,130);
insert into olympics.athelete(id, "name", sex,  height, weight) values(19,'Win Valdemar Aaltonen','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(20,'Kjetil Andr Aamodt','M',176,85);
insert into olympics.athelete(id, "name", sex,  height, weight) values(21,'Ragnhild Margrethe Aamodt','F',163,75);
insert into olympics.athelete(id, "name", sex,  height, weight) values(22,'Andreea Aanei','F',170,125);
insert into olympics.athelete(id, "name", sex,  height, weight) values(23,'Fritz Aanes','M',187,89);
insert into olympics.athelete(id, "name", sex,  height, weight) values(24,'Nils Egil Aaness','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(25,'Alf Lied Aanning','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(26,'Agnes Erika Aanonsen (-Eyde)','F',169,65);
insert into olympics.athelete(id, "name", sex,  height, weight) values(27,'Johan Aantjes','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(28,'Jan-Erik Aarberg','M',170,77);
insert into olympics.athelete(id, "name", sex,  height, weight) values(29,'Willemien Aardenburg','F',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(30,'Pepijn Aardewijn','M',189,72);
insert into olympics.athelete(id, "name", sex,  height, weight) values(31,'Evald rma (rman-)','M',174,70);
insert into olympics.athelete(id, "name", sex,  height, weight) values(32,'Olav Augunson Aarnes','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(33,'Mika Lauri Aarnikka','M',187,76);
insert into olympics.athelete(id, "name", sex,  height, weight) values(34,'Jamale (Djamel-) Aarrass (Ahrass-)','M',187,76);
insert into olympics.athelete(id, "name", sex,  height, weight) values(35,'Dagfinn Sverre Aarskog','M',190,98);
insert into olympics.athelete(id, "name", sex,  height, weight) values(36,'Stefan Remco Aartsen','M',194,78);
insert into olympics.athelete(id, "name", sex,  height, weight) values(37,'Ann Kristin Aarnes','F',182,64);
insert into olympics.athelete(id, "name", sex,  height, weight) values(38,'Karl Jan Aas','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(39,'Lars Thorlaksn Aas','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(40,'Roald Edgar Aas','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(41,'Rolf Aas','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(42,'Thomas Valentin Aas','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(43,'Morten Gjerdrum Aasen','M',185,75);
insert into olympics.athelete(id, "name", sex,  height, weight) values(44,'Meelis Aasme','M',182,73);
insert into olympics.athelete(id, "name", sex,  height, weight) values(45,'Hakon Aasns','M',null,null);
insert into olympics.athelete(id, "name", sex,  height, weight) values(46,'Hans Aasns','M',194,93);
insert into olympics.athelete(id, "name", sex,  height, weight) values(47,'Erling Rudolf Aastad','M',177,74);
insert into olympics.athelete(id, "name", sex,  height, weight) values(48,'Abdelhak Aatakni','M',null,64);
insert into olympics.athelete(id, "name", sex,  height, weight) values(49,'Moonika Aava','F',168,65);
insert into olympics.athelete(id, "name", sex,  height, weight) values(50,'Arvi Aavik','M',185,106);

-- insert into part of

insert into olympics.part_of(NOC, athelete_id) values('CHN',1);
insert into olympics.part_of(NOC, athelete_id) values('CHN',2);
insert into olympics.part_of(NOC, athelete_id) values('DEN',3);
insert into olympics.part_of(NOC, athelete_id) values('DEN',4);
insert into olympics.part_of(NOC, athelete_id) values('NED',5);
insert into olympics.part_of(NOC, athelete_id) values('USA',6);
insert into olympics.part_of(NOC, athelete_id) values('USA',7);
insert into olympics.part_of(NOC, athelete_id) values('NED',8);
insert into olympics.part_of(NOC, athelete_id) values('FIN',9);
insert into olympics.part_of(NOC, athelete_id) values('FIN',10);
insert into olympics.part_of(NOC, athelete_id) values('FIN',11);
insert into olympics.part_of(NOC, athelete_id) values('FIN',12);
insert into olympics.part_of(NOC, athelete_id) values('FIN',13);
insert into olympics.part_of(NOC, athelete_id) values('FIN',14);
insert into olympics.part_of(NOC, athelete_id) values('FIN',15);
insert into olympics.part_of(NOC, athelete_id) values('FIN',16);
insert into olympics.part_of(NOC, athelete_id) values('FIN',17);
insert into olympics.part_of(NOC, athelete_id) values('FIN',18);
insert into olympics.part_of(NOC, athelete_id) values('FIN',19);
insert into olympics.part_of(NOC, athelete_id) values('NOR',20);
insert into olympics.part_of(NOC, athelete_id) values('NOR',21);
insert into olympics.part_of(NOC, athelete_id) values('ROU',22);
insert into olympics.part_of(NOC, athelete_id) values('NOR',23);
insert into olympics.part_of(NOC, athelete_id) values('NOR',24);
insert into olympics.part_of(NOC, athelete_id) values('NOR',25);
insert into olympics.part_of(NOC, athelete_id) values('NOR',26);
insert into olympics.part_of(NOC, athelete_id) values('NED',27);
insert into olympics.part_of(NOC, athelete_id) values('NOR',28);
insert into olympics.part_of(NOC, athelete_id) values('NED',29);
insert into olympics.part_of(NOC, athelete_id) values('NED',30);
insert into olympics.part_of(NOC, athelete_id) values('EST',31);
insert into olympics.part_of(NOC, athelete_id) values('NOR',32);
insert into olympics.part_of(NOC, athelete_id) values('FIN',33);
insert into olympics.part_of(NOC, athelete_id) values('FRA',34);
insert into olympics.part_of(NOC, athelete_id) values('NOR',35);
insert into olympics.part_of(NOC, athelete_id) values('NED',36);
insert into olympics.part_of(NOC, athelete_id) values('NOR',37);
insert into olympics.part_of(NOC, athelete_id) values('NOR',38);
insert into olympics.part_of(NOC, athelete_id) values('NOR',39);
insert into olympics.part_of(NOC, athelete_id) values('NOR',40);
insert into olympics.part_of(NOC, athelete_id) values('NOR',41);
insert into olympics.part_of(NOC, athelete_id) values('NOR',42);
insert into olympics.part_of(NOC, athelete_id) values('NOR',43);
insert into olympics.part_of(NOC, athelete_id) values('EST',44);
insert into olympics.part_of(NOC, athelete_id) values('NOR',45);
insert into olympics.part_of(NOC, athelete_id) values('NOR',46);
insert into olympics.part_of(NOC, athelete_id) values('NOR',47);
insert into olympics.part_of(NOC, athelete_id) values('MAR',48);
insert into olympics.part_of(NOC, athelete_id) values('EST',49);
insert into olympics.part_of(NOC, athelete_id) values('EST',50);


--insert into olympics.team
insert into olympics.team(Country, NOC) values('Chinull','CHN');
insert into olympics.team(Country, NOC) values('Denmark','DEN');
insert into olympics.team(Country, NOC) values('Netherlands','NED');
insert into olympics.team(Country, NOC) values('United States','USA');
insert into olympics.team(Country, NOC) values('Finland','FIN');
insert into olympics.team(Country, NOC) values('Norway','NOR');
insert into olympics.team(Country, NOC) values('Romania','ROU');
insert into olympics.team(Country, NOC) values('Estonia','EST');
insert into olympics.team(Country, NOC) values('France'	,'FRA');
insert into olympics.team(Country, NOC) values('Morocco',	'MAR');




-- insert into olympics.olympic_games
insert into olympics.olympic_games (city, "year", season) values('barcelona',	1992,'Summer');
insert into olympics.olympic_games (city, "year", season) values('London'	,2012	,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Antwerpen',	1920,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Paris',	1900	,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Calgary',	1988	,'Winter');
insert into olympics.olympic_games (city, "year", season) values('Albertville',	1992,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Lillehammer',1994,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Los Angeles',	1932,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Salt Lake City',	2002	,'Winter');
insert into olympics.olympic_games (city, "year", season) values('Helsinki',	1952,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Lake Placid',	1980,'Winter');
insert into olympics.olympic_games (city, "year", season) values('Sydney',2000	,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Atlanta',	1996,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Stockholm',	1912	,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Paris',	1924,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Sochi',	2014,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('London',	1948,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Nagano'	,1998,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Torino',	2006,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Rio de Janeiro'	,2016,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Squaw Valley'	,1960,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Innsbruck'	,1964,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Sarajevo'	,1984,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Los Angeles'	,1984,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Mexico City'	,1968	,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Munich',	1972,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Seoul',	1988,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Oslo'	,1952,'Winter');
insert into olympics.olympic_games (city, "year", season) values('Cortinull d Ampezzo',	1956,	'Winter');
insert into olympics.olympic_games (city, "year", season) values('Berlin',1936,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Melbourne'	,1956,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Roma'	,1960,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Amsterdam'	,1928,	'Summer');
insert into olympics.olympic_games (city, "year", season) values('Athina'	,2004	,'Summer');
insert into olympics.olympic_games (city, "year", season) values('Beijing',	2008,'Summer');



-- insert into olympics.particpate_in
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('CHN',	'barcelona',	1992);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('CHN','London'	,2012);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('DEN','Antwerpen',	1920);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('DEN','Paris'	,1900);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Calgary',	1988);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Albertville',	1992);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Lillehammer',	1994);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('USA','Albertville',	1992);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('USA','Lillehammer',	1994);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Los Angeles',	1932);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Salt Lake City',2002);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Helsinki',	1952);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Lake Placid',	1980);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Sydney',	2000);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Atlanta',	1996);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Lillehammer',	1994);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Stockholm',	1912);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Antwerpen',	1920);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Paris',	1924);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','Sochi',	2014);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','London',	1948);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Albertville',	1992);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Lillehammer',	1994);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Nagano'	,1998);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Salt Lake City',	2002);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Torino'	,2006);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Beijing',	2008);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('ROU','Rio de Janeiro',	2016);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Sydney',	2000);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Athina',	2004);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Squaw Valley',	1960);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Innsbruck',	1964);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Antwerpen',	1920);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Sarajevo',	1984);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Los Angeles',	1984);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Mexico City',	1968);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Munich',	1972);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Seoul',	1988);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Atlanta',	1996);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NED','Sydney',	2000);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('EST','Berlin',	1936);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Stockholm',	1912);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FIN','barcelona',	1992);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('FRA','London',	2012);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Atlanta',	1996);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Oslo',	1952);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Cortinull d Ampezzo',	1956);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','barcelona',	1992);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('EST','Nagano',	1998);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('EST','Salt Lake City',	2002);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Berlin',	1936);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','London',	1948);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Helsinki',	1952);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Melbourne',	1956);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Roma',	1960);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Paris',	1924);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('NOR','Amsterdam',	1928);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('MAR','London',	2012);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('EST','Athina',	2004);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('EST','Beijing',	2008);
insert into olympics.participates_in (team_noc, olympic_city, olympic_year) values('EST','barcelona',	1992);



-- insert into olympics.performs_in
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(1	,'barcelona',1992,'Basketball Mens Basketball',null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(2	,'London',	2012,	'Judo Mens Extra-Lightweight', null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(3	,'Antwerpen'	,1920,	'Football Mens Football'	,null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(4	,'Paris',	1900	,'Tug-Of-War Mens Tug-Of-War',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(5	,'Calgary',	1988	,'Speed Skating Womens 500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(5	,'Calgary',	1988	,'Speed Skating Womens 1,000 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(5	,'Albertville',	1992,'	Speed Skating Womens 500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(5	,'Albertville',	1992,'	Speed Skating Womens 1,000 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(5	,'Lillehammer',	1994,'	Speed Skating Womens 500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(5	,'Lillehammer',	1994,'	Speed Skating Womens 1,000 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Albertville',	1992,'	Cross Country Skiing Mens 10 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Albertville',	1992,'	Cross Country Skiing Mens 50 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Albertville',	1992,'	Cross Country Skiing Mens 10/15 kilometres Pursuit',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Albertville',	1992,'	Cross Country Skiing Mens 4 x 10 kilometres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Lillehammer',	1994,'	Cross Country Skiing Mens 10 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Lillehammer',	1994,'	Cross Country Skiing Mens 30 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Lillehammer',	1994,'	Cross Country Skiing Mens 10/15 kilometres Pursuit',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(6	,'Lillehammer',	1994,'	Cross Country Skiing Mens 4 x 10 kilometres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Albertville',	1992,'	Cross Country Skiing Mens 10 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Albertville',	1992,'	Cross Country Skiing Mens 50 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Albertville',	1992,'	Cross Country Skiing Mens 10/15 kilometres Pursuit',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Albertville',	1992,'Cross Country Skiing Mens 4 x 10 kilometres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Lillehammer',	1994,'	Cross Country Skiing Mens 10 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Lillehammer',	1994,'	Cross Country Skiing Mens 30 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Lillehammer',	1994,'	Cross Country Skiing Mens 10/15 kilometres Pursuit',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(7	,'Lillehammer',	1994,'	Cross Country Skiing Mens 4 x 10 kilometres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(8	,'Los Angeles',	1932,'	Athletics Womens 100 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(8	,'Los Angeles',	1932,'	Athletics Womens 4 x 100 metres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(9	,'Salt Lake City',	2002,'	Ice Hockey Mens Ice Hockey',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(10	,'Helsinki',	1952,'	Swimming Mens 400 metres Freestyle',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(11	,'Lake Placid',	1980,'	Cross Country Skiing Mens 30 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(12	,'Sydney',	2000,'	Badminton Mens Singles',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(13	,'Atlanta',	1996,'	Sailing Womens Windsurfer',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(13	,'Sydney',	2000,'	Sailing Womens Windsurfer',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(14	,'Lillehammer',	1994,'	Biathlon Womens 7.5 kilometres Sprint',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(15	,'Stockholm',	1912,'	Swimming Mens 200 metres Breaststroke',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(15	,'Stockholm',	1912,'	Swimming Mens 400 metres Breaststroke',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(15	,'Antwerpen',1920,'	Swimming Mens 200 metres Breaststroke',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(15	,'Antwerpen',	1920,'	Swimming Mens 400 metres Breaststroke',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(15	,'Paris',	1924,'	Swimming Men 200 metres Breaststroke',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(16	,'Sochi',2014,'	Ice Hockey Mens Ice Hockey',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Individual All-Around',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Team All-Around',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Floor Exercise',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Horse Vault',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Parallel Bars',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Horizontal Bar',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Rings',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'London',	1948,'	Gymnullstics Mens Pommelled Horse',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Individual All-Around',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Team All-Around',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Floor Exercise',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Horse Vault',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Parallel Bars',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Horizontal Bar',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Rings',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(17	,'Helsinki',	1952,'	Gymnullstics Mens Pommelled Horse',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(18	,'Sydney',	2000,'	Athletics Mens Shot Put',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(19	,'London',	1948,'	Art Competitions Mixed Sculpturing, Unknown Event',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Albertville',	1992,'	Alpine Skiing Mens Downhill',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Albertville',	1992,'	Alpine Skiing Mens Super G',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Albertville',	1992,'	Alpine Skiing Mens Giant Slalom',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Albertville',	1992,'	Alpine Skiing Mens Slalom',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Lillehammer',	1994,'	Alpine Skiing Mens Downhill',	'Silver');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Lillehammer',	1994,'	Alpine Skiing Mens Super G',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Lillehammer',	1994,'	Alpine Skiing Mens Giant Slalom',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Lillehammer',	1994,'	Alpine Skiing Mens Slalom',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Lillehammer',	1994,'	Alpine Skiing Mens Combined',	'Silver');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Nagano',	1998,'	Alpine Skiing Mens Downhill',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Nagano',	1998,'	Alpine Skiing Mens Super G',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Nagano',	1998,'	Alpine Skiing Mens Giant Slalom',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Nagano',	1998,'	Alpine Skiing Mens Combined',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Salt Lake City',	2002,'	Alpine Skiing Mens Downhill',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Salt Lake City',	2002,'	Alpine Skiing Mens Super G',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Salt Lake City',	2002,'	Alpine Skiing Mens Giant Slalom',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Salt Lake City',	2002,'	Alpine Skiing Mens Slalom',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Salt Lake City',	2002,'	Alpine Skiing Mens Combined',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Torino',	2006,'	Alpine Skiing Mens Downhill',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(20	,'Torino',	2006,'	Alpine Skiing Mens Super G',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(21	,'Beijing',	2008,'	Handball Womens Handball',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(22	,'Rio de Janeiro',	2016,'	Weightlifting Womens Super-Heavyweight',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(23	,'Sydney',	2000,'	Wrestling Mens Light-Heavyweight, Greco-Roman',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(23	,'Athina',	2004,'	Wrestling Mens Light-Heavyweight, Greco-Roman',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(24	,'Squaw Valley',	1960,'	Speed Skating Mens 500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(24	,'Squaw Valley',	1960,'	Speed Skating Mens 1,500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(24	,'Innsbruck',	1964,'	Speed Skating Mens 1,500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(25	,'Antwerpen',	1920,'	Gymnullstics Mens Team All-Around, Free System',	'Silver');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(26	,'Sarajevo',	1984,'	Luge Womens Singles',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(27	,'Los Angeles',	1984,'	Water Polo Mens Water Polo',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(28	,'Mexico City',	1968,'	Sailing Mixed Three Person Keelboat',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(28	,'Munich',	1972,'	Sailing Mixed Three Person Keelboat',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(29	,'Seoul',	1988,'	Hockey Womens Hockey',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(30	,'Atlanta',	1996,'	Rowing Mens Lightweight Double Sculls',	'Silver');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(30	,'Sydney',	2000,'	Rowing Mens Lightweight Double Sculls',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(31	,'Berlin',	1936,'	Athletics Mens Pole Vault',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(32	,'Stockholm',	1912,'	Athletics Mens High Jump',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(33	,'barcelona',	1992,'	Sailing Mens Two Person Dinghy',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(33	,'Atlanta',	1996,'	Sailing Mens Two Person Dinghy',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(34	,'London',	2012,'	Athletics Mens 1,500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(35	,'Nagano',	1998,'	Bobsleigh Mens Four',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(36	,'Atlanta',	1996,'	Swimming Mens 100 metres Butterfly',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(36	,'Atlanta',	1996,'	Swimming Mens 200 metres Butterfly',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(36	,'Atlanta',	1996,'	Swimming Mens 4 x 100 metres Medley Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(36	,'Sydney',	2000,'	Swimming Mens 100 metres Butterfly',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(36	,'Sydney',	2000,'	Swimming Mens 200 metres Butterfly',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(37	,'Atlanta'	,1996,	'Football Womens Football'	,'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(38	,'Antwerpen',	1920,	'Gymnullstics Mens Team All-Around, Free System',	'Silver');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(39	,'Stockholm',	1912,'	Fencing Mens Foil, Individual',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(39	,'Stockholm',	1912,'	Fencing Mens epee, Individual',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(39	,'Stockholm',	1912,'	Fencing Mens epee, Team',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(40	,'Oslo',	1952,'	Speed Skating Mens 1,500 metres',	'Bronze');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(40	,'Cortinull d Ampezzo',	1956,'	Speed Skating Mens 1,500 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(40	,'Cortinull d Ampezzo',	1956,'	Speed Skating Mens 5,000 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(40	,'Squaw Valley',	1960,'	Speed Skating Mens 1,500 metres',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(40	,'Squaw Valley',	1960,'	Speed Skating Mens 5,000 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(40	,'Squaw Valley',	1960,'	Speed Skating Mens 10,000 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(41	,'Antwerpen',	1920,'	Football Mens Football',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(42	,'Stockholm',	1912,'	Sailing Mixed 8 metres',	'Gold');
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(43	,'barcelona',	1992,'	Equestrianism Mixed Jumping, Individual',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(44	,'Nagano',	1998,'	Cross Country Skiing Mens 30 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(44,	'Nagano',	1998,'	Cross Country Skiing Mens 50 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(44	,'Salt Lake City',	2002,'	Cross Country Skiing Mens 15 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(44,	'Salt Lake City',	2002,'	Cross Country Skiing Mens 50 kilometres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(44,	'Salt Lake City',	2002,'Cross Country Skiing Mens 4 x 10 kilometres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(45,	'Berlin',	1936,'	Shooting Mens Small-Bore Rifle, Prone, 50 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(46,	'Berlin',	1936	,'Shooting Mens Rapid-Fire Pistol, 25 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(46	,'London',	1948,	'Shooting Mens Rapid-Fire Pistol, 25 metres',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(46	,'Helsinki',	1952	,'Shooting Mens Trap',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(46	,'Melbourne',	1956	,'Shooting Mens Trap',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(46	,'Roma',	1960,	'Shooting Mens Trap'	,null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(47	,'Antwerpen',	1920	,'Athletics Mens 4 x 100 metres Relay',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(47,	'Antwerpen',	1920	,'Athletics Mens Long Jump',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(47	,'Paris',	1924,	'Athletics Mens Long Jump',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(47	,'Amsterdam'	,1928,	'Athletics Mens Long Jump'	,null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(48,	'London'	,2012,	'Boxing Mens Light-Welterweight',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(49,	'Athina'	,2004	,'Athletics Womens Javelin Throw',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(49,	'Beijing',	2008	,'Athletics Womens Javelin Throw',	null);
insert into olympics.performs_in (athelete_id, olympic_city, olympic_year, "Event", "result") values(50,	'barcelona'	,1992,	'Wrestling Mens Heavyweight, Freestyle'	,null);

-- foriegn keys


alter table only olympics.performs_in
	add constraint athID_fk1 foreign key (athelete_id) references olympics.athelete(id);


alter table only olympics.performs_in
	add constraint athID_fk2 foreign key (olympic_city,olympic_year) references olympics.olympic_games(city,year);

alter table only olympics.participates_in
	add constraint athID_fk1 foreign key (olympic_city,olympic_year) references olympics.olympic_games(city,year);

alter table only olympics.participates_in
	add constraint athID_fk2 foreign key (team_noc) references olympics.team(NOC);

alter table only olympics.part_of
	add constraint athID_fk2 foreign key (athelete_id) references olympics.athelete(id);



