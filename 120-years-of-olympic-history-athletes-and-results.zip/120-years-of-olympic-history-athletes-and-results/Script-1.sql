--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;
COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';

-- to enable functions like crosstab
CREATE EXTENSION IF NOT EXISTS tablefunc;


create table athelete(
	ID INT ,
	"name" Varchar(300) not null,
	sex varchar(1),
	"age" INT,
	"height" INT,
	weight INT
);


ALTER TABLE athelete OWNER TO postgres;

select * from athelete


create table Team (
	NOC varchar(30),
	COUNTRY Varchar(30),
	athelete_ID INT
);

ALTER TABLE Team OWNER TO postgres;

select*from team;


create table olympic_games(
	city Varchar(40),
	"year" INT,
	season varchar(20)
);

ALTER TABLE olympic_games OWNER TO postgres;


create table performs_in(
	athelete_ID INT,
	olympic_city Varchar(40),
	olympic_year int,
	"result" varchar(30),
	"event" varchar(50)
);

ALTER TABLE performs_in OWNER TO postgres;



create table participates_in(
	team_NOC varchar(15),
	olympic_city Varchar(40),
	olympic_year int
);

ALTER TABLE participates_in OWNER TO postgres;

-- primary keys

ALTER TABLE ONLY athelete
    ADD CONSTRAINT prim_key_athelete PRIMARY KEY (id, age);

ALTER TABLE ONLY team
    ADD CONSTRAINT prim_key_team PRIMARY KEY (NOC);

ALTER TABLE ONLY olympic_games
    ADD CONSTRAINT prim_key_ogames PRIMARY KEY (city, "year");

ALTER TABLE ONLY performs_in
    ADD CONSTRAINT prim_key_Perin PRIMARY KEY (athelete_ID, olympic_city, olympic_year);

ALTER TABLE ONLY participates_in
    ADD CONSTRAINT prim_key_parin PRIMARY KEY (team_NOC, olympic_city, olympic_year);

-- foriegn key

ALTER TABLE ONLY athelete
    ADD CONSTRAINT athelete_fk1 FOREIGN KEY (id) REFERENCES performs_in(athelete_id);	

   --copy data from csv

copy public.athelete(id,"name") from 'C:\Users\dell\Desktop\Studies\FoDatabase\project\athlete_events.csv' with csv header

COPY athelete("name") FROM 'athlete_events.csv' DELIMITER ',' CSV;




-- adding constraint-

	primary key(olympic_city,olympic_year,athelete_ID),
	foreign key(athelete_ID) references athelete(ID) on delete cascade,
	foreign key(olympic_city) references olympic_games(city) on delete cascade,
	foreign key(olympic_year) references olympic_games("year") on delete cascade
	
	foreign key(team_noc) references team(noc) on delete cascade,
	foreign key(olympic_city) references olympic_games(city) on delete cascade,
	foreign key(olympic_year) references olympic_games("year") on delete cascade
	

drop table participates_in

drop table performs_in

drop table athelete

drop table olympic_games

drop table team




